from scipy.linalg import eigh
import numpy as np
import matplotlib.pyplot as plt


def load_and_center_dataset(filename):
    x = np.load(filename)
    x_cent = x - np.mean(x, axis=0)
    return x_cent


def get_covariance(dataset):
    n = len(dataset)
    x = dataset
    x_trans = np.transpose(dataset)
    dot_prod = np.dot(x_trans, x)
    return dot_prod/(n-1)


def get_eig(S, m):
    eig_vals, eig_vecs = eigh(S, subset_by_index=[len(S)-m, len(S)-1])
    largest_eig_vecs = np.transpose(eig_vecs)
    largest_eig_vecs = np.flip(largest_eig_vecs, 0)
    largest_eig_vecs = np.transpose(largest_eig_vecs)
    diag_matrix = np.zeros((m, m))
    for i in range(m):
        diag_matrix[len(eig_vals) - 1 - i, len(eig_vals) - 1 - i] = eig_vals[i]
    return diag_matrix, largest_eig_vecs


def get_eig_prop(S, prop):

    eig_vals, eig_vacs = eigh(S)
    sum_eig_vals = np.sum(eig_vals)
    i = 0
    for vals in eig_vals:
        if vals/sum_eig_vals > prop:
            i += 1
    return get_eig(S, i)


def project_image(image, U):
    # function solved under help of chatGPT
    m = U.shape[1]
    alpha = np.zeros(m)
    for j in range(m):
        uj = U[:, j]
        alpha[j] = np.dot(uj.T, image)
    x_pca = np.zeros(image.shape)
    for j in range(m):
        uj = U[:, j]
        x_pca = x_pca + alpha[j] * uj
    return x_pca


def display_image(orig, proj):
    orig_img = np.transpose(orig.reshape(32, 32))
    proj_img = np.transpose(proj.reshape(32, 32))
    fig, axs = plt.subplots(1, 2)


    axs[0].set_title('Original')
    im1 = axs[0].imshow(orig_img, aspect='equal')
    fig.colorbar(im1, ax=axs[0])

    axs[1].set_title('Projection')
    im2 = axs[1].imshow(proj_img, aspect='equal')
    fig.colorbar(im2, ax=axs[1])

    plt.show()


